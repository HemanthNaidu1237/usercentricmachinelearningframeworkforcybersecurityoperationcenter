from django.apps import AppConfig


class CyberAlertConfig(AppConfig):
    name = 'cyber_alert'
